alert('alert send from app-script.js, if its yellow the css is working');
