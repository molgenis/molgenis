package org.molgenis.r;

public interface ROutputHandler
{
	void outputReceived(String output);
}
